# Project Name: Student Result Management System
## How to run this Project

### 1. Download and Unzip file.
    * For Windows copy srms folder to `xampp/htdocs/`
    * For Ubuntu copy srms folder to `/opt/lampp/htdocs/`

### 2. Database Configuration for Xampp
    * Open phpmyadmin
    * Create Database_srms
    * Import database Database_srms.sql (available inside `/sql` folder)

### 3. For User

    * Open Your browser put inside browser http://localhost/srms
### 4. For Admin Panel

    * Open Your browser put inside browser http://localhost/srms
    * Login Details for admin : admin/12345